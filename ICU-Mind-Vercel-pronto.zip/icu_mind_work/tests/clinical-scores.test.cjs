const test=require('node:test');
const assert=require('node:assert/strict');
const {extract,calculate}=require('../clinical-scores.js');
const data=values=>Object.fromEntries(Object.entries(values).map(([key,value])=>[key,{value,source:'fixture'}]));
const baseline={age:70,weight:70,sex:'male',creatinine:1,platelets:150,bilirubin:1,temperature:37,heartRate:80,leukocytes:12,ph:7.4,sbp:120,map:80,pao2:90,fio2:.21,gcs:15,urine:1500,ventilation:false,respiratorySupport:false,noVasoactives:true,hypertension:false,heartFailure:false,diabetes:false,stroke:false,strokeTIA:false,vascular:false,uncontrolledHTN:false,abnormalRenal:false,abnormalLiver:false,bleeding:false,labileINR:false,bleedingDrugs:false,alcohol:false,hospitalDays:0,location:'emergency',vasoactiveBefore:false,planned:'unplanned',surgery:'none',infection:'none',comorbidities:['none'],reasons:['other'],sapsWindow:true,sofaWindow:true};
test('complete independent reference case: SAPS3 42, SOFA 0, HAS-BLED 1, CHA2DS2-VASc 1, CG 68.06',()=>{
 const r=calculate(data(baseline));
 assert.equal(r.saps.value,42);assert.equal(r.sofa.value,0);assert.equal(r.hasbled.value,1);assert.equal(r.chads.value,1);assert.ok(Math.abs(r.crcl.value-68.0555556)<.0001);
});
test('missing data never produces normal scores; no complete result on empty source',()=>{
 const r=calculate(extract('Hemoglobina: 12 g/dL; sódio: 140 mmol/L'));
 Object.values(r).forEach(result=>{assert.equal(result.complete,false);assert.equal(result.value,null);assert.ok(result.missing.length>0)});
});
test('Portuguese decimals, thousands, units and multiple inline labeled observations',()=>{
 const d=extract('Paciente de 70 anos; sexo: masculino; peso: 70 kg; creatinina: 106,08 µmol/L; bilirrubina total: 34,2 µmol/L; plaquetas: 150.000 /mm³; leucócitos: 12.000 /µL; FiO2: 30%; diurese 24h: 1,5 L/24h; FC: 80 bpm PAM: 75 mmHg');
 assert.ok(Math.abs(d.creatinine.value-1.2)<1e-6);assert.equal(d.bilirubin.value,2);assert.equal(d.platelets.value,150);assert.equal(d.leukocytes.value,12);assert.equal(d.fio2.value,.3);assert.equal(d.urine.value,1500);assert.equal(d.heartRate.value,80);assert.equal(d.map.value,75);assert.equal(d.age.value,70);
});
test('missing lab units, FiO2 40 without %, and mL/h doses are rejected',()=>{
 for(const [text,key] of [['creatinina: 1,2','creatinine'],['plaquetas: 150','platelets'],['FiO2: 40','fio2'],['noradrenalina: 5 mL/h','norepinephrine']]) {
  const d=extract(text);assert.equal(d[key].value,null,text);assert.ok(d[key].error,text);
 }
});
test('repeated identical values are accepted, conflicts are not selected by order',()=>{
 assert.equal(extract('creatinina: 1 mg/dL; creatinina: 1 mg/dL').creatinine.value,1);
 assert.match(extract('creatinina: 1 mg/dL; creatinina: 2 mg/dL').creatinine.error,/conflitantes/);
});
test('negated histories and missing histories are different; INR alone is not labile INR',()=>{
 const d=extract('nega HAS; sem diabetes; AVC prévio: não; INR: 4');
 assert.equal(d.hypertension.value,false);assert.equal(d.diabetes.value,false);assert.equal(d.stroke.value,false);assert.equal(d.labileINR,undefined);assert.equal(d.heartFailure,undefined);
});
test('Cockcroft Gault uses the female factor, requires age/weight/sex/Cr, blocks AKI',()=>{
 const r=calculate(data({age:70,weight:70,sex:'female',creatinine:1}));assert.ok(Math.abs(r.crcl.value-57.847222)<.0001);
 assert.equal(calculate(data({age:70,weight:70,creatinine:1})).crcl.complete,false);
 assert.equal(calculate(data({...baseline,acuteKidney:true})).crcl.complete,false);
});
test('CHA2DS2-VASc age tiers do not double count; HAS-BLED age strictly >65',()=>{
 for(const [age,expected] of [[64,0],[65,1],[74,1],[75,2]]) assert.equal(calculate(data({...baseline,age})).chads.value,expected);
 assert.equal(calculate(data({...baseline,age:65})).hasbled.value,0);
 assert.equal(calculate(data({...baseline,age:66})).hasbled.value,1);
 assert.equal(calculate(data({...baseline,age:80,sex:'female',heartFailure:true,hypertension:true,diabetes:true,strokeTIA:true,vascular:true})).chads.value,9);
});
test('HAS-BLED maximum is 9; hypertension diagnosis alone does not establish uncontrolled BP',()=>{
 assert.equal(calculate(data({...baseline,uncontrolledHTN:true,abnormalRenal:true,abnormalLiver:true,stroke:true,bleeding:true,labileINR:true,bleedingDrugs:true,alcohol:true})).hasbled.value,9);
 const {uncontrolledHTN,...rest}=baseline;assert.equal(calculate(data({...rest,hypertension:true})).hasbled.complete,false);
});
test('HAS-BLED renal and hepatic lab criteria retain their required history/ULNs',()=>{
 let d={...baseline};delete d.abnormalRenal;delete d.abnormalLiver;
 let r=calculate(data({...d,creatinine:3,cirrhosis:false,bilirubin:3,bilirubinULN:1,ast:150,astULN:40}));
 assert.equal(r.hasbled.parts[1].points,1);assert.equal(r.hasbled.parts[2].points,1);
 r=calculate(data({...d,creatinine:1,bilirubin:1,cirrhosis:false}));assert.equal(r.hasbled.parts[1].points,null);assert.equal(r.hasbled.parts[2].points,null);
});
test('SOFA platelet, bilirubin, GCS and creatinine threshold boundaries',()=>{
 const points=(key,v,label)=>calculate(data({...baseline,[key]:v})).sofa.parts.find(p=>p.label.startsWith(label)).points;
 for(const [v,p] of [[150,0],[149,1],[100,1],[99,2],[50,2],[49,3],[20,3],[19,4]])assert.equal(points('platelets',v,'Coagulação'),p);
 for(const [v,p] of [[1.19,0],[1.2,1],[2,2],[6,3],[12,4]])assert.equal(points('bilirubin',v,'Fígado'),p);
 for(const [v,p] of [[15,0],[14,1],[13,1],[12,2],[10,2],[9,3],[6,3],[5,4]])assert.equal(points('gcs',v,'Neurológico'),p);
 for(const [v,p] of [[1.19,0],[1.2,1],[2,2],[3.5,3],[5,4]])assert.equal(points('creatinine',v,'Renal'),p);
 assert.equal(points('urine',199,'Renal'),4);assert.equal(points('urine',499,'Renal'),3);assert.equal(points('urine',500,'Renal'),0);
});
test('SOFA vasoactive thresholds, no-support declaration conflict, and respiratory support requirement',()=>{
 const pressors={noVasoactives:false,norepinephrine:0,epinephrine:0,dopamine:0,dobutamine:0};
 const cardio=v=>calculate(data({...baseline,...pressors,...v})).sofa.parts[3].points;
 assert.equal(cardio({map:69}),1);assert.equal(cardio({dobutamine:1}),2);assert.equal(cardio({dopamine:5}),2);assert.equal(cardio({dopamine:5.1}),3);assert.equal(cardio({dopamine:15}),3);assert.equal(cardio({dopamine:15.1}),4);assert.equal(cardio({norepinephrine:.1}),3);assert.equal(cardio({norepinephrine:.10001}),4);assert.equal(cardio({noVasoactives:true,norepinephrine:.1}),null);
 assert.equal(calculate(data({...baseline,pf:99,respiratorySupport:true,pao2:99,fio2:1})).sofa.parts[0].points,4);
 assert.equal(calculate(data({...baseline,pf:199,respiratorySupport:false,pao2:199,fio2:1})).sofa.parts[0].points,2);
 const {respiratorySupport, ...noSupport}=baseline;
 assert.equal(calculate(data({...noSupport,pf:99,pao2:99,fio2:1})).sofa.parts[0].points,null);
});
test('SOFA does not finalize renal score without urine except an already maximum renal component',()=>{
 const {urine,...rest}=baseline;assert.equal(calculate(data(rest)).sofa.complete,false);assert.equal(calculate(data({...rest,creatinine:5})).sofa.parts[5].points,4);
});
test('SAPS 3 all nonzero elements against original tables; additive comorbidity/reasons and negative categories',()=>{
 const r=calculate(data({...baseline,age:80,comorbidities:['therapy','nyha','hematologic','cirrhosis','aids','metastatic'],hospitalDays:28,location:'ward',vasoactiveBefore:true,planned:'unplanned',reasons:['arrhythmia','seizures','septic','liver'],surgery:'emergency',surgerySite:'transplant',infection:'hospital',infectionSite:'respiratory',gcs:3,bilirubin:6,temperature:34,creatinine:3.5,heartRate:160,leukocytes:15,ph:7.25,platelets:19,sbp:39,ventilation:true,pf:99,pao2:99,fio2:1}));
 // 16+18+42+7+8+3+3+7+6-11+4+5+15+5+7+8+7+2+3+13+11+11 = 190
 assert.equal(r.saps.value,190);
});
test('SAPS 3 admission window and SOFA 24-hour window are mandatory, not inferred from lab timestamps',()=>{
 const {sapsWindow,sofaWindow,...rest}=baseline;const r=calculate(data(rest));assert.equal(r.saps.complete,false);assert.equal(r.sofa.complete,false);
});
test('full Portuguese canonical text produces complete outputs without manually entering scores',()=>{
 const text=`idade: 70; sexo: masculino; peso: 70 kg; creatinina: 1 mg/dL; bilirrubina total: 1 mg/dL; plaquetas: 150.000 /mm3; leucocitos: 12.000 /mm3; temperatura: 37 °C; FC: 80 bpm; pH: 7,40; PAS: 120 mmHg; PAM: 80 mmHg; Glasgow: 15; PaO2: 90 mmHg; FiO2: 21%; diurese 24h: 1.500 mL/24h; ventilacao mecanica: nao; suporte respiratorio: nao; sem DVA: sim; HAS: nao; insuficiencia cardiaca: nao; diabetes: nao; AVC previo: nao; AVC/AIT/embolia: nao; doenca vascular: nao; hipertensao nao controlada: nao; disfuncao renal HAS-BLED: nao; disfuncao hepatica HAS-BLED: nao; sangramento previo: nao; INR labil: nao; antiagregante/AINE: nao; alcool HAS-BLED: nao; dias antes da UTI: 0; procedencia: pronto-socorro; DVA antes da UTI: nao; admissao UTI: nao planejada; cirurgia: sem cirurgia; infeccao: sem infeccao; comorbidades SAPS3: nenhuma; motivos admissao: outros; janela SAPS3: sim; janela SOFA: sim`;
 const d=extract(text);for(const [key,item] of Object.entries(d))assert.equal(item.error,undefined,key+': '+JSON.stringify(item));const r=calculate(d);for(const result of Object.values(r))assert.equal(result.complete,true,result.name+': '+result.missing.join(', '));assert.equal(r.saps.value,42);assert.equal(r.sofa.value,0);
});

test('clinical contradictions block the affected component rather than favoring a lower risk',()=>{
 const r=calculate(data({...baseline,abnormalRenal:false,creatinine:3,abnormalLiver:false,cirrhosis:true,labileINR:false,ttr:40,stroke:true,strokeTIA:false,pf:99,pao2:90,fio2:.21}));
 assert.equal(r.hasbled.complete,false);assert.equal(r.chads.complete,false);assert.equal(r.sofa.parts[0].points,null);
 assert.match(r.sofa.parts[0].label,/contradiz/);
});
test('SAPS 3 threshold rows match the published admission score sheet',()=>{
 const score=(key,value,label)=>calculate(data({...baseline,[key]:value})).saps.parts.find(p=>p.label===label).points;
 const tables=[
  ['age','Idade',[[39,0],[40,5],[59,5],[60,9],[69,9],[70,13],[74,13],[75,15],[79,15],[80,18]]],
  ['gcs','Glasgow',[[3,15],[4,15],[5,10],[6,7],[7,2],[12,2],[13,0],[15,0]]],
  ['bilirubin','Bilirrubina',[[1.99,0],[2,4],[5.99,4],[6,5]]],
  ['creatinine','Creatinina',[[1.19,0],[1.2,2],[1.99,2],[2,7],[3.49,7],[3.5,8]]],
  ['platelets','Plaquetas',[[19,13],[20,8],[49,8],[50,5],[99,5],[100,0]]],
  ['sbp','Pressão sistólica',[[39,11],[40,8],[69,8],[70,3],[119,3],[120,0]]],
  ['heartRate','Frequência cardíaca',[[119,0],[120,5],[159,5],[160,7]]],
  ['hospitalDays','Internação antes da UTI',[[13,0],[14,6],[27,6],[28,7]]],
  ['temperature','Temperatura',[[34.9,7],[35,0]]],
  ['ph','pH',[[7.25,3],[7.26,0]]],
  ['leukocytes','Leucócitos',[[14.99,0],[15,2]]]
 ];
 for(const [key,label,cases] of tables)for(const [value,expected] of cases)assert.equal(score(key,value,label),expected,`${key}=${value}`);
 const oxygen=values=>calculate(data({...baseline,...values})).saps.parts.find(p=>p.label==='Oxigenação e ventilação mecânica').points;
 assert.equal(oxygen({ventilation:false,pao2:59}),5);assert.equal(oxygen({ventilation:false,pao2:60}),0);
 assert.equal(oxygen({ventilation:true,pao2:99,fio2:1}),11);assert.equal(oxygen({ventilation:true,pao2:100,fio2:1}),7);
});
